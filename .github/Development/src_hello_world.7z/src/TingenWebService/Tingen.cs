﻿using RarelySimple.AvatarScriptLink.Objects;

namespace TingenWebService
{
    public class Tingen : ITingen
    {
        public string GetVersion()
        {
            return "0.1.0";
        }

        public OptionObject2015 RunScript(OptionObject2015 optionObject, string parameter)
        {
            return optionObject.ToReturnOptionObject(ErrorCode.Alert, "Hello World!");
        }
    }
}
